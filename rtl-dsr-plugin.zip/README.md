# RTL-SDR pour Home Assistant

> Custom integration qui pilote une clé **RTL-SDR** branchée en USB sur Home Assistant OS.

Elle expose l'état du dongle et de la bande observée sous forme d'entités Home Assistant, avec des services pour piloter la réception depuis des automatisations.

---

## ✨ Fonctionnalités

- 🔍 **Détection automatique** du dongle RTL-SDR (RTL2832U / R820T2, etc.)
- 📡 **Capteurs temps réel** : RSSI, niveau du bruit, fréquence & puissance du pic spectral
- 🎛 **Réglages exposés** : fréquence centrale, fréquence d'échantillonnage, gain, correction PPM, bande passante, squelch
- 📻 **Modes de démodulation** : `off`, `spectrum`, `nfm`, `wfm`, `am`, `usb`, `lsb`, `raw`
- 🔘 **Raccourcis de scan** : FM (87–108 MHz), ISM 433 MHz, ISM 868 MHz, ADS-B 1090 MHz
- ⚙️ **Config Flow** : installation depuis l'interface, sans YAML
- 🌍 **Interface en français et en anglais**
- 🔌 **Services** exploitables dans les automatisations (voir plus bas)

---

## 🖥️ Interface SDR++ (Panel Card)

Une **carte Lovelace responsive** « SDR++ Card » est fournie dans [`panel/sdrplusplus/`](panel/sdrplusplus/) : spectre temps réel, waterfall, S‑mètre, tuning tactile/PC et raccourcis de bande (FM, ISM 433/868, ADS‑B 1090). Voir [`panel/sdrplusplus/README.md`](panel/sdrplusplus/README.md) pour l'installation.

**Aperçu rapide** :
1. Copier `card.js` et `sdr-plus-plus-card.js` dans `/config/www/rtl_dsr/`
2. Ajouter la ressource Lovelace : `/local/rtl_dsr/card.js` en **module**
3. Ajouter une carte personnalisée `type: custom:sdr-plus-plus-card`

---

## 📦 Installation

### Via HACS (recommandé)

1. HACS → **Intégrations** → menu **⋮** → **Repositories personnalisés**
2. Ajoute `https://github.com/<ton-user>/rtl-dsr` en catégorie **Integration**
3. Recherche **RTL-SDR** dans HACS et clique **Télécharger**
4. **Redémarre Home Assistant**

### Installation manuelle

```bash
# Sur ton Home Assistant (add-on Terminal & SSH ou Studio Code Server)
cd /config
git clone https://github.com/<ton-user>/rtl-dsr.git /tmp/rtl-dsr
cp -r /tmp/rtl-dsr/custom_components/rtl_dsr /config/custom_components/
# (Optionnel) Interface SDR++
mkdir -p /config/www/rtl_dsr
cp /tmp/rtl-dsr/panel/sdrplusplus/card.js /tmp/rtl-dsr/panel/sdrplusplus/sdr-plus-plus-card.js /config/www/rtl_dsr/
# Redémarre Home Assistant
```

---

## 🔧 Prérequis système

L'intégration s'appuie sur **`pyrtlsdr`** (déclaré dans `manifest.json` et installé automatiquement). Pour que la bibliothèque native `librtlsdr` voie ta clé USB, il faut :

1. **Home Assistant OS** avec l'add-on **RTL_433** ou **rtl-sdr** installé (il fournit les binaires et le support USB),
2. ou une **installation Supervised / Container** avec `librtlsdr0` installé sur l'hôte.

Vérifie que ta clé est visible :

```bash
lsusb | grep -i realtek
# 0bda:2838 Realtek Semiconductor Corp. RTL2838 DVB-T
```

> **Astuce** — installe l'add-on **RTL_433** depuis le store Home Assistant même si tu ne l'utilises pas : il gère le passage de la clé USB au conteneur Home Assistant Core.

---

## 🚀 Mise en route

1. **Paramètres → Appareils et services → Ajouter une intégration → RTL-SDR**
2. Choisis l'**index du périphérique** (0 pour la première clé)
3. Renseigne la **fréquence d'échantillonnage**, la **fréquence centrale** et le **gain** initiaux

L'appareil `RTL-SDR #0 (R820T)` apparaît avec les entités suivantes :

| Domaine | Entité | Rôle |
|---|---|---|
| `sensor` | `sensor.rtl_sdr_0_rssi` | Niveau de signal |
| `sensor` | `sensor.rtl_sdr_0_noise_floor` | Plancher de bruit |
| `sensor` | `sensor.rtl_sdr_0_peak_freq` | Fréquence du pic spectral |
| `sensor` | `sensor.rtl_sdr_0_peak_power` | Puissance du pic |
| `sensor` | `sensor.rtl_sdr_0_tuner_type` / `_serial` | Diagnostics |
| `binary_sensor` | `binary_sensor.rtl_sdr_0_connected` | Connecté ? |
| `binary_sensor` | `binary_sensor.rtl_sdr_0_signal_detected` | Signal > squelch |
| `number` | `number.rtl_sdr_0_frequency` | Fréquence centrale (MHz) |
| `number` | `number.rtl_sdr_0_sample_rate` | Échantillonnage (MHz) |
| `number` | `number.rtl_sdr_0_ppm` | Correction PPM |
| `number` | `number.rtl_sdr_0_bandwidth` | Bande passante (MHz) |
| `number` | `number.rtl_sdr_0_squelch` | Seuil de squelch (dB) |
| `select` | `select.rtl_sdr_0_mode` | Mode de réception |
| `select` | `select.rtl_sdr_0_gain` | Gain tuner (auto / manuel) |
| `switch`  | `switch.rtl_sdr_0_preamp` | Préampli |
| `switch`  | `switch.rtl_sdr_0_reception` | Allumage réception |
| `button`  | `button.rtl_sdr_0_scan_fm` / `_scan_ism_433` / `_scan_ism_868` / `_scan_adsb` / `_reset` | Raccourcis |

---

## 🛠 Services

Tous les services acceptent un `device_id` optionnel pour cibler une clé précise.

### `rtl_dsr.set_frequency`
```yaml
service: rtl_dsr.set_frequency
data:
  frequency: 101.1    # MHz
```

### `rtl_dsr.set_sample_rate`
```yaml
service: rtl_dsr.set_sample_rate
data:
  sample_rate: 2.048  # MHz (MS/s)
```

### `rtl_dsr.set_gain`
```yaml
service: rtl_dsr.set_gain
data:
  gain: "28.0"        # ou "auto"
```

### `rtl_dsr.set_ppm`
```yaml
service: rtl_dsr.set_ppm
data:
  ppm: -2
```

### `rtl_dsr.set_mode`
```yaml
service: rtl_dsr.set_mode
data:
  mode: wfm           # off, spectrum, nfm, wfm, am, usb, lsb, raw
```

### `rtl_dsr.set_preamp`
```yaml
service: rtl_dsr.set_preamp
data:
  preamp: true
```

### `rtl_dsr.set_bandwidth`
```yaml
service: rtl_dsr.set_bandwidth
data:
  bandwidth: 0.2      # MHz, 0 = auto
```

### `rtl_dsr.set_squelch`
```yaml
service: rtl_dsr.set_squelch
data:
  level: -90          # dB
```

### `rtl_dsr.reset`
```yaml
service: rtl_dsr.reset
```

---

## 💡 Automatisations d'exemple

### Notification quand un signal ISM est détecté
```yaml
automation:
  - alias: "Alerte signal ISM 433"
    trigger:
      - platform: state
        entity_id: binary_sensor.rtl_sdr_0_signal_detected
        to: "on"
    condition:
      - condition: numeric_state
        entity_id: sensor.rtl_sdr_0_peak_freq
        above: 433.5
        below: 434.5
    action:
      - service: notify.mobile_app_pixel_6a
        data:
          title: "Signal ISM 433 MHz"
          message: "Pic détecté à {{ states('sensor.rtl_sdr_0_peak_freq') }} MHz ({{ states('sensor.rtl_sdr_0_peak_power') }} dB)"
```

### Balayage automatique de la bande FM toutes les 5 minutes
```yaml
script:
  scan_fm:
    sequence:
      - service: rtl_dsr.set_frequency
        data: { frequency: 87.6 }
      - service: rtl_dsr.set_mode
        data: { mode: wfm }
      - delay: "00:00:05"
      - service: rtl_dsr.set_frequency
        data: { frequency: 107.9 }
```

---

## 🧪 Mode « sans matériel »

Si `pyrtlsdr` n'est pas disponible, l'intégration bascule sur un **MockSdr** qui renvoie des données simulées. Utile pour tester les cartes et les automatisations avant de brancher la clé.

---

## 🧰 Dépannage

| Symptôme | Cause probable | Solution |
|---|---|---|
| `cannot_connect` au setup | Clé non vue par HA | Installe l'add-on **RTL_433** ou **rtl-sdr** |
| `ImportError: rtlsdr` | `librtlsdr0` manquant | Installe l'add-on ou `apt install librtlsdr0` |
| RSSI toujours à -120 dB | Mauvais gain / fréquence | Monte le gain, vérifie la fréquence centrale |
| `Failed to open` en USB | Clé utilisée par un autre add-on | Arrête temporairement l'add-on **RTL_433** |

---

## 📄 Licence

MIT © votre_nom
